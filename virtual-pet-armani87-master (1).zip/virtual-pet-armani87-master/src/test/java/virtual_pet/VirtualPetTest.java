package virtual_pet;
public class VirtualPetTest {
}
